from __future__ import annotations

import asyncio
import logging
import os
import re
import sqlite3
import unicodedata
from contextlib import closing
from pathlib import Path
from typing import Optional

import discord
from discord import app_commands
from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
ASSET_PATH = BASE_DIR / "assets" / "나쁜말.jpg"
TERMS_PATH = Path(os.getenv("TERMS_FILE", BASE_DIR / "profanity_terms.txt"))
if not TERMS_PATH.is_absolute():
    TERMS_PATH = BASE_DIR / TERMS_PATH
DB_PATH = Path(os.getenv("COUNT_DB_PATH", BASE_DIR / "counts.sqlite3"))
if not DB_PATH.is_absolute():
    DB_PATH = BASE_DIR / DB_PATH

IMAGE_FILENAME = "profanity-filter.jpg"
CHOSEONG = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
JAMO_TO_COMPAT = {chr(0x1100 + index): char for index, char in enumerate(CHOSEONG)}
HANGUL_BASE = 0xAC00
HANGUL_END = 0xD7A3
DIGITS = re.compile(r"[0-9]+")
INITIAL_RUN = re.compile(r"[ㄱ-ㅎ]{2,}")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("profanity-filter")


def canonical_text(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    return "".join(JAMO_TO_COMPAT.get(char, char) for char in normalized)


def normalize_for_detection(value: str) -> str:
    return DIGITS.sub("", canonical_text(value))


def to_initials(value: str) -> str:
    result: list[str] = []
    for char in value:
        codepoint = ord(char)
        if HANGUL_BASE <= codepoint <= HANGUL_END:
            initial_index = (codepoint - HANGUL_BASE) // 588
            result.append(CHOSEONG[initial_index])
        else:
            result.append(char)
    return "".join(result)


def is_hangul_syllables(value: str) -> bool:
    return bool(value) and all(HANGUL_BASE <= ord(char) <= HANGUL_END for char in value)


def load_profanity_terms(path: Path) -> tuple[list[str], list[str]]:
    if not path.exists():
        raise FileNotFoundError(f"욕설 단어 목록 파일을 찾을 수 없습니다: {path}")

    terms: list[str] = []
    initial_terms: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        term = canonical_text(line.split("#", 1)[0].strip())
        if not term or term in {"바보", "멍청이"}:
            continue
        terms.append(term)
        if is_hangul_syllables(term) and len(term) >= 2:
            initial_terms.append(to_initials(term))

    if not terms:
        raise ValueError("profanity_terms.txt에 욕설 기준 단어를 한 개 이상 적어 주세요.")
    return terms, list(dict.fromkeys(initial_terms))


def build_profanity_pattern(terms: list[str], initial_terms: list[str]) -> re.Pattern:
    variants = sorted(set(terms + initial_terms), key=lambda term: (-len(term), term))
    patterns = [
        re.escape(term) if any(char.isdigit() for char in term)
        else r"[0-9]*".join(re.escape(char) for char in term)
        for term in variants if term not in {"바보", "멍청이"}
    ]
    return re.compile("|".join(patterns))


def count_profanity(content: str, pattern: re.Pattern) -> int:
    return sum(1 for _ in pattern.finditer(canonical_text(content)))


def count_nickname(display_name: str, count: int) -> str:
    base = re.sub(r"\s*\[욕설 \d+회\]$", "", display_name).strip() or "사용자"
    suffix = f" [욕설 {count}회]"
    return base[:max(0, 32 - len(suffix))] + suffix


class CounterStore:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS profanity_counts (
                    guild_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    count INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (guild_id, user_id)
                )
                """
            )

    def increment(self, guild_id: int, user_id: int, amount: int = 1) -> int:
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute(
                """
                INSERT INTO profanity_counts (guild_id, user_id, count)
                VALUES (?, ?, ?)
                ON CONFLICT(guild_id, user_id)
                DO UPDATE SET count = count + excluded.count
                """,
                (str(guild_id), str(user_id), amount),
            )
            row = db.execute(
                "SELECT count FROM profanity_counts WHERE guild_id = ? AND user_id = ?",
                (str(guild_id), str(user_id)),
            ).fetchone()
        return int(row[0]) if row else 0

    def get_count(self, guild_id: int, user_id: int) -> int:
        with closing(sqlite3.connect(self.path)) as db, db:
            row = db.execute(
                "SELECT count FROM profanity_counts WHERE guild_id = ? AND user_id = ?",
                (str(guild_id), str(user_id)),
            ).fetchone()
        return int(row[0]) if row else 0

    def top(self, guild_id: int, limit: int = 10) -> list[tuple[int, int]]:
        with closing(sqlite3.connect(self.path)) as db, db:
            rows = db.execute(
                """
                SELECT user_id, count
                FROM profanity_counts
                WHERE guild_id = ?
                ORDER BY count DESC, user_id ASC
                LIMIT ?
                """,
                (str(guild_id), limit),
            ).fetchall()
        return [(int(user_id), int(count)) for user_id, count in rows]


class ProfanityFilterBot(discord.Client):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = True
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)
        self.store = CounterStore(DB_PATH)
        self.terms, self.initial_terms = load_profanity_terms(TERMS_PATH)
        self.profanity_pattern = build_profanity_pattern(self.terms, self.initial_terms)
        self.member_locks: dict[tuple[int, int], asyncio.Lock] = {}
        raw_alert_channel_id = os.getenv("ALERT_CHANNEL_ID", "").strip()
        try:
            self.alert_channel_id = int(raw_alert_channel_id) if raw_alert_channel_id else None
        except ValueError as exc:
            raise ValueError("ALERT_CHANNEL_ID에는 Discord 채널 ID 숫자만 입력해 주세요.") from exc

    async def setup_hook(self) -> None:
        synced = await self.tree.sync()
        log.info("슬래시 명령어 %s개를 동기화했습니다.", len(synced))

    async def on_ready(self) -> None:
        log.info("로그인 완료: %s", self.user)

    async def on_message(self, message: discord.Message) -> None:
        if message.guild is None or message.author.bot or message.webhook_id is not None:
            return
        amount = count_profanity(message.content, self.profanity_pattern)
        if amount == 0:
            return
        guild = message.guild
        member = message.author
        key = (guild.id, member.id)
        async with self.member_locks.setdefault(key, asyncio.Lock()):
            count = self.store.increment(guild.id, member.id, amount)
            log.info("채팅 욕설 집계: guild=%s user=%s added=%s count=%s",
                     guild.id, member.id, amount, count)
            member = guild.get_member(member.id) or member
            me = guild.me
            if me is None or not me.guild_permissions.manage_nicknames:
                log.warning("별명 변경 실패: 봇에 별명 관리 권한이 필요합니다. guild=%s", guild.id)
            elif member.id == guild.owner_id or member.top_role >= me.top_role:
                log.warning("별명 변경 불가: 서버 소유자 또는 봇보다 높은/같은 역할. user=%s", member.id)
            else:
                try:
                    await member.edit(nick=count_nickname(member.display_name, count),
                                      reason="채팅 욕설 누적 횟수 표시")
                except discord.HTTPException:
                    log.exception("별명 변경 실패: guild=%s user=%s", guild.id, member.id)
            channel = (guild.get_channel(self.alert_channel_id)
                       if self.alert_channel_id is not None else guild.system_channel)
            if not isinstance(channel, discord.TextChannel):
                log.warning("시스템 알림 채널이 없습니다. 서버 시스템 채널을 설정하거나 "
                            "ALERT_CHANNEL_ID를 지정하세요. guild=%s", guild.id)
                return
            safe_name = discord.utils.escape_markdown(" ".join(member.name.split()))
            alert = ("욕설감지\n"
                     f"'{safe_name}'님의 욕설 횟수 {amount}회 추가\n"
                     f"현재 스택:{count}")
            try:
                await channel.send(alert, allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException:
                log.exception("알림 전송 실패: 채널 보기/메시지 보내기 권한을 확인하세요. "
                              "guild=%s channel=%s", guild.id, channel.id)


client = ProfanityFilterBot()


async def send_branded_embed(
    interaction: discord.Interaction,
    embed: discord.Embed,
) -> None:
    embed.set_thumbnail(url=f"attachment://{IMAGE_FILENAME}")
    image = discord.File(ASSET_PATH, filename=IMAGE_FILENAME)
    await interaction.response.send_message(
        embed=embed,
        file=image,
        ephemeral=True,
        allowed_mentions=discord.AllowedMentions.none(),
    )


@client.tree.command(name="욕설횟수", description="서버에서 집계된 채팅 욕설 횟수를 조회합니다.")
@app_commands.guild_only()
async def profanity_count(
    interaction: discord.Interaction,
    member: Optional[discord.Member] = None,
) -> None:
    if interaction.guild_id is None:
        return
    target = member or interaction.user
    count = client.store.get_count(interaction.guild_id, target.id)
    embed = discord.Embed(
        title="욕설 필터 · 횟수 조회",
        description=f"{target.mention}님의 집계 횟수는 **{count}회**입니다.",
        color=discord.Color.from_rgb(255, 92, 142),
    )
    await send_branded_embed(interaction, embed)


@client.tree.command(name="욕설순위", description="이 서버의 채팅 욕설 집계 순위를 보여줍니다.")
@app_commands.guild_only()
async def profanity_leaderboard(interaction: discord.Interaction) -> None:
    if interaction.guild_id is None:
        return
    rows = client.store.top(interaction.guild_id)
    embed = discord.Embed(
        title="욕설 필터 · 서버 순위",
        color=discord.Color.from_rgb(255, 92, 142),
    )
    if rows:
        embed.description = "\n".join(
            f"**{place}.** <@{user_id}> — **{count}회**"
            for place, (user_id, count) in enumerate(rows, start=1)
        )
    else:
        embed.description = "아직 집계된 기록이 없습니다."
    await send_branded_embed(interaction, embed)


def main() -> None:
    token = os.getenv("DISCORD_BOT_TOKEN", "").strip()
    if not token or token == "PASTE_TOKEN_HERE":
        raise SystemExit(".env 파일의 DISCORD_BOT_TOKEN에 봇 토큰을 입력해 주세요.")
    if not ASSET_PATH.exists():
        raise SystemExit(f"봇 이미지 파일을 찾을 수 없습니다: {ASSET_PATH}")
    client.run(token)


if __name__ == "__main__":
    main()
